package com.tecshare.outbox;

import static org.junit.jupiter.api.Assertions.*;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Test;

class OutboxRelayTest {
    private static final Instant START = Instant.parse("2026-11-02T00:00:00Z");
    private OutboxRelay.Event pending(String id, int attempts) {
        return new OutboxRelay.Event(id, attempts, OutboxRelay.Status.PENDING, START, null);
    }
    @Test void retriesAtExactDueTimeThenMarksSent() {
        AtomicInteger calls = new AtomicInteger();
        OutboxRelay relay = new OutboxRelay(event -> {
            if (calls.incrementAndGet() == 1) throw new IllegalStateException("broker timeout");
        });
        relay.add(pending("evt-1", 0));
        var failed = relay.poll(START).get(0);
        assertEquals(OutboxRelay.Status.PENDING, failed.status());
        assertEquals(1, failed.attempts());
        assertEquals(START.plusSeconds(2), failed.availableAt());
        relay.poll(failed.availableAt().minusNanos(1));
        assertEquals(1, calls.get());
        var sent = relay.poll(failed.availableAt()).get(0);
        assertEquals(OutboxRelay.Status.SENT, sent.status());
        assertEquals(2, sent.attempts());
        assertEquals(2, calls.get());
        System.out.println("retry event_id=evt-1 failed_at=" + START + " next_at=" + failed.availableAt() + " final=" + sent.status());
    }
    @Test void publishThenCrashLeavesClaimAndRedeliversAfterLease() {
        var store = new OutboxRelay.InMemoryStore();
        List<String> deliveries = new ArrayList<>();
        Set<String> processed = new HashSet<>();
        AtomicInteger effects = new AtomicInteger();
        OutboxRelay.Publisher broker = event -> {
            deliveries.add(event.eventId());
            boolean applied = processed.add(event.eventId());
            if (applied) effects.incrementAndGet();
            System.out.println("broker event_id=" + event.eventId() + " attempt=" + event.attempts() + " business_applied=" + applied);
        };
        var firstProcess = new OutboxRelay(store, broker, event -> { throw new OutboxRelay.ProcessCrash(); });
        firstProcess.add(pending("evt-crash", 0));
        assertThrows(OutboxRelay.ProcessCrash.class, () -> firstProcess.poll(START));
        assertEquals(OutboxRelay.Status.PROCESSING, store.snapshot().get(0).status());
        var restarted = new OutboxRelay(store, broker, event -> {});
        restarted.poll(START.plusSeconds(4));
        assertEquals(1, deliveries.size());
        var result = restarted.poll(START.plusSeconds(5)).get(0);
        assertEquals(List.of("evt-crash", "evt-crash"), deliveries);
        assertEquals(1, effects.get());
        assertEquals(OutboxRelay.Status.SENT, result.status());
        System.out.println("recovery claim_expiry=" + START.plusSeconds(5) + " deliveries=" + deliveries.size() + " effects=" + effects.get());
    }
    @Test void allThreeFailuresExhaustBudgetWithoutFurtherPublish() {
        AtomicInteger calls = new AtomicInteger();
        OutboxRelay relay = new OutboxRelay(event -> { calls.incrementAndGet(); throw new IllegalArgumentException("invalid payload"); });
        relay.add(pending("evt-dead", 0));
        var one = relay.poll(START).get(0);
        var two = relay.poll(one.availableAt()).get(0);
        var three = relay.poll(two.availableAt()).get(0);
        assertEquals(START.plusSeconds(2), one.availableAt());
        assertEquals(START.plusSeconds(6), two.availableAt());
        assertEquals(OutboxRelay.Status.DEAD, three.status());
        assertEquals(3, three.attempts());
        assertEquals("invalid payload", three.lastError());
        relay.poll(START.plusSeconds(999));
        assertEquals(3, calls.get());
        System.out.println("dead event_id=evt-dead attempts=" + three.attempts() + " last_error=" + three.lastError());
    }
    @Test void expiredFinalAttemptBecomesDeadWithUnknownDeliveryOutcome() {
        var store = new OutboxRelay.InMemoryStore();
        var relay = new OutboxRelay(store, event -> {}, event -> { throw new OutboxRelay.ProcessCrash(); });
        relay.add(pending("evt-uncertain", 2));
        assertThrows(OutboxRelay.ProcessCrash.class, () -> relay.poll(START));
        var recovered = new OutboxRelay(store, event -> fail("Must not republish exhausted event"), event -> {});
        var result = recovered.poll(START.plusSeconds(5)).get(0);
        assertEquals(OutboxRelay.Status.DEAD, result.status());
        assertTrue(result.lastError().contains("may have succeeded"));
    }
    @Test void olderClaimCannotMarkNewerClaimSent() throws Exception {
        var store = new OutboxRelay.InMemoryStore();
        CountDownLatch oldPublished = new CountDownLatch(1), resumeOld = new CountDownLatch(1);
        var old = new OutboxRelay(store, event -> {}, event -> {
            oldPublished.countDown();
            try { if (!resumeOld.await(5, TimeUnit.SECONDS)) throw new IllegalStateException("timeout"); }
            catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); throw new IllegalStateException(interrupted); }
        });
        old.add(pending("evt-overlap", 0));
        ExecutorService executor = Executors.newSingleThreadExecutor();
        try {
            var paused = executor.submit(() -> old.poll(START));
            assertTrue(oldPublished.await(5, TimeUnit.SECONDS));
            var newer = new OutboxRelay(store, event -> { throw new IllegalStateException("retry me"); }, event -> {});
            var pending = newer.poll(START.plusSeconds(5)).get(0);
            assertEquals(2, pending.attempts());
            assertEquals(OutboxRelay.Status.PENDING, pending.status());
            resumeOld.countDown();
            paused.get(5, TimeUnit.SECONDS);
            assertEquals(pending, store.snapshot().get(0));
        } finally { resumeOld.countDown(); executor.shutdownNow(); }
    }
    @Test void sentRowsAreNotPublishedAgain() {
        AtomicInteger calls = new AtomicInteger();
        var relay = new OutboxRelay(event -> calls.incrementAndGet());
        relay.add(pending("evt-once", 0));
        relay.poll(START);
        relay.poll(START.plusSeconds(100));
        assertEquals(1, calls.get());
    }
    @Test void duplicateEventIdIsRejectedAtInsertion() {
        var relay = new OutboxRelay(event -> {});
        relay.add(pending("evt-same", 0));
        assertThrows(IllegalArgumentException.class, () -> relay.add(pending("evt-same", 0)));
    }
    @Test void backoffHasOneImplementationAndIsCapped() {
        assertEquals(Duration.ofSeconds(2), OutboxRelay.retryDelay(1));
        assertEquals(Duration.ofSeconds(4), OutboxRelay.retryDelay(2));
        assertEquals(Duration.ofSeconds(900), OutboxRelay.retryDelay(30));
        assertThrows(IllegalArgumentException.class, () -> OutboxRelay.retryDelay(0));
    }
}
