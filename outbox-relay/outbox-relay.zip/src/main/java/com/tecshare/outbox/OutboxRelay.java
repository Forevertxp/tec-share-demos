package com.tecshare.outbox;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/** In-memory failure experiment, not a durable database or broker implementation. */
public final class OutboxRelay {
    public enum Status { PENDING, PROCESSING, SENT, DEAD }
    /** attempts counts claimed delivery attempts, including one interrupted before broker acceptance. */
    public record Event(String eventId, int attempts, Status status, Instant availableAt, String lastError) {}
    public interface Publisher { void publish(Event event) throws Exception; }
    public interface Consumer { boolean applyOnce(String eventId); }
    public interface AfterPublish { void run(Event event); }
    /** Bypasses the normal failure handler to leave an unfinished claim. */
    public static final class ProcessCrash extends Error {
        public ProcessCrash() { super("injected crash after publish before markSent"); }
    }
    /** Shared across simulated relay restarts. Does NOT survive an actual process exit. */
    public static final class InMemoryStore {
        private final Map<String, Event> events = new LinkedHashMap<>();
        public synchronized void add(Event event) {
            Objects.requireNonNull(event.eventId());
            Objects.requireNonNull(event.status());
            Objects.requireNonNull(event.availableAt());
            if (event.attempts() < 0) throw new IllegalArgumentException("Negative attempts");
            if (events.putIfAbsent(event.eventId(), event) != null) throw new IllegalArgumentException("Duplicate event_id");
        }
        private synchronized List<Event> claimDue(Instant now, Duration lease, int maxAttempts) {
            List<Event> claimed = new ArrayList<>();
            for (Event event : new ArrayList<>(events.values())) {
                if ((event.status() != Status.PENDING && event.status() != Status.PROCESSING)
                        || event.availableAt().isAfter(now)) continue;
                if (event.attempts() >= maxAttempts) {
                    events.put(event.eventId(), new Event(event.eventId(), event.attempts(), Status.DEAD, now,
                            "attempt budget exhausted; previous delivery may have succeeded"));
                    continue;
                }
                Event processing = new Event(event.eventId(), event.attempts() + 1, Status.PROCESSING,
                        now.plus(lease), event.lastError());
                events.put(event.eventId(), processing);
                claimed.add(processing);
            }
            return claimed;
        }
        private synchronized boolean finish(Event claim, Event replacement) {
            // Resuming an old worker must not acknowledge a newer claim.
            return events.replace(claim.eventId(), claim, replacement);
        }
        public synchronized List<Event> snapshot() { return List.copyOf(events.values()); }
    }
    private static final int MAX_ATTEMPTS = 3;
    private static final Duration LEASE = Duration.ofSeconds(5);
    private final InMemoryStore store;
    private final Publisher publisher;
    private final AfterPublish afterPublish;
    public OutboxRelay(Publisher publisher) { this(new InMemoryStore(), publisher, event -> {}); }
    public OutboxRelay(InMemoryStore store, Publisher publisher, AfterPublish afterPublish) {
        this.store = Objects.requireNonNull(store);
        this.publisher = Objects.requireNonNull(publisher);
        this.afterPublish = Objects.requireNonNull(afterPublish);
    }
    public void add(Event event) { store.add(event); }
    public List<Event> poll(Instant now) {
        for (Event processing : store.claimDue(now, LEASE, MAX_ATTEMPTS)) {
            try {
                publisher.publish(processing);
                afterPublish.run(processing);
                store.finish(processing, new Event(processing.eventId(), processing.attempts(), Status.SENT, now, null));
            } catch (Exception failure) {
                Status status = processing.attempts() >= MAX_ATTEMPTS ? Status.DEAD : Status.PENDING;
                store.finish(processing, new Event(processing.eventId(), processing.attempts(), status,
                        now.plus(retryDelay(processing.attempts())), failure.getMessage()));
            }
        }
        return store.snapshot();
    }
    /** Deterministic backoff for reproducible tests; production should add bounded jitter. */
    public static Duration retryDelay(int attempt) {
        if (attempt < 1) throw new IllegalArgumentException("attempt must be positive");
        return Duration.ofSeconds(Math.min(900, 1L << Math.min(attempt, 10)));
    }
}
