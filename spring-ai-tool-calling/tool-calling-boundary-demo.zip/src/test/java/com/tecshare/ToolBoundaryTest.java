package com.tecshare;

import java.util.*;
import java.util.concurrent.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.*;
import org.springframework.ai.chat.model.*;
import org.springframework.ai.chat.prompt.*;
import org.springframework.ai.model.tool.ToolCallingChatOptions;
import org.springframework.ai.support.ToolCallbacks;

class ToolBoundaryTest {
    static final OrderTools.Caller OWNER = new OrderTools.Caller("acme","user-7");
    static final class ScriptedModel implements ChatModel {
        final List<Prompt> prompts = new ArrayList<>();
        final String name, json;
        ScriptedModel(String name, String json) { this.name=name; this.json=json; }
        @Override public ChatOptions getOptions() { return ToolCallingChatOptions.builder().build(); }
        @Override public ChatResponse call(Prompt prompt) {
            prompts.add(prompt);
            AssistantMessage output=prompts.size()==1 ? AssistantMessage.builder().content("")
                .toolCalls(List.of(new AssistantMessage.ToolCall("call-1","function",name,json)))
                .build() : new AssistantMessage("Order ORD-42 is paid.");
            return new ChatResponse(List.of(new Generation(output)));
        }
    }
    static String call(ScriptedModel model, OrderTools tools) {
        return ChatClient.builder(model).build().prompt()
            .options(ToolCallingChatOptions.builder()).tools(tools)
            .user("What is the status of ORD-42?").call().content();
    }
    static String callback(OrderTools tools, String json) { return ToolCallbacks.from(tools)[0].call(json); }

    @Test void successfulRoundTripCarriesMatchingToolResult() {
        var tools=new OrderTools(OWNER);
        var model=new ScriptedModel("orderStatus","{\"orderId\":\"ORD-42\"}");
        assertEquals("Order ORD-42 is paid.",call(model,tools));
        assertEquals(2,model.prompts.size()); assertEquals(1,tools.businessReads.get());
        var response=model.prompts.get(1).getInstructions().stream()
            .filter(ToolResponseMessage.class::isInstance).map(ToolResponseMessage.class::cast)
            .findFirst().orElseThrow().getResponses().get(0);
        assertEquals("call-1",response.id()); assertTrue(response.responseData().contains("PAID"));
        System.out.println("round-trip modelCalls=2 businessReads=1 responseId="+response.id());
    }
    @Test void unknownToolStopsBeforeMethodEntry() {
        var tools=new OrderTools(OWNER); var model=new ScriptedModel("notRegistered","{}");
        assertThrows(RuntimeException.class,()->call(model,tools));
        assertEquals(1,model.prompts.size()); assertEquals(0,tools.methodEntries.get());
    }
    @Test void malformedJsonStopsBeforeMethodEntry() {
        var tools=new OrderTools(OWNER); var model=new ScriptedModel("orderStatus","{");
        call(model,tools);
        assertEquals(2,model.prompts.size());
        assertEquals(0,tools.methodEntries.get()); assertEquals(0,tools.businessReads.get());
        var error=model.prompts.get(1).getInstructions().stream().filter(ToolResponseMessage.class::isInstance)
            .map(ToolResponseMessage.class::cast).findFirst().orElseThrow().getResponses().get(0).responseData();
        assertFalse(error.isBlank());
        System.out.println("malformed JSON methodEntries=0 modelCalls=2 toolResult="+error);
    }
    @Test void blankArgumentDoesNotReadBusinessData() {
        var tools=new OrderTools(OWNER);
        assertTrue(callback(tools,"{\"orderId\":\"\"}").contains("INVALID_ARGUMENT"));
        assertEquals(0,tools.businessReads.get());
    }
    @Test void otherActorCannotReadOrder() {
        var tools=new OrderTools(new OrderTools.Caller("acme","user-8"));
        assertTrue(callback(tools,"{\"orderId\":\"ORD-42\"}").contains("ORDER_UNAVAILABLE"));
        assertEquals(1,tools.methodEntries.get()); assertEquals(0,tools.businessReads.get());
    }
    @Test void otherTenantCannotReadOrder() {
        var tools=new OrderTools(new OrderTools.Caller("beta","user-7"));
        assertTrue(callback(tools,"{\"orderId\":\"ORD-42\"}").contains("ORDER_UNAVAILABLE"));
        assertEquals(0,tools.businessReads.get());
    }
    @Test void missingAndDeniedOrdersSharePublicResponse() {
        assertEquals(callback(new OrderTools(OWNER),"{\"orderId\":\"MISSING\"}"),
            callback(new OrderTools(new OrderTools.Caller("acme","user-8")),"{\"orderId\":\"ORD-42\"}"));
    }
    @Test void deniedResultReturnsThroughFrameworkWithoutBusinessRead() {
        var tools=new OrderTools(new OrderTools.Caller("beta","user-7"));
        var model=new ScriptedModel("orderStatus","{\"orderId\":\"ORD-42\"}");
        call(model,tools);
        assertEquals(2,model.prompts.size()); assertEquals(0,tools.businessReads.get());
        assertTrue(model.prompts.get(1).getInstructions().stream().filter(ToolResponseMessage.class::isInstance)
            .map(ToolResponseMessage.class::cast).anyMatch(m->m.getResponses().get(0).responseData().contains("ORDER_UNAVAILABLE")));
    }
    @Test void duplicateReplaysOriginalResult() {
        var ledger=new CreditLedger();
        var first=ledger.credit(OWNER,"req-1","ORD-42",100,false);
        assertEquals(first,ledger.credit(OWNER,"req-1","ORD-42",100,false));
        assertEquals(1,ledger.effects()); assertEquals(100,ledger.balance());
        System.out.println("duplicate effects=1 balance=100 result="+first);
    }
    @Test void changedAmountConflictsWithoutSecondEffect() {
        var ledger=new CreditLedger(); ledger.credit(OWNER,"req-1","ORD-42",100,false);
        assertEquals("IDEMPOTENCY_CONFLICT",ledger.credit(OWNER,"req-1","ORD-42",200,false));
        assertEquals(100,ledger.balance()); assertEquals(1,ledger.effects());
    }
    @Test void preEffectFailureCanRetry() {
        var ledger=new CreditLedger();
        assertThrows(IllegalStateException.class,()->ledger.credit(OWNER,"req-1","ORD-42",100,true));
        assertEquals(0,ledger.effects());
        assertEquals("CREDITED:req-1:100",ledger.credit(OWNER,"req-1","ORD-42",100,false));
        assertEquals(1,ledger.effects());
        System.out.println("pre-effect failure -> retry effects=1 balance="+ledger.balance());
    }
    @Test void concurrentDuplicatesHaveOneEffect() throws Exception {
        var ledger=new CreditLedger(); var pool=Executors.newFixedThreadPool(8);
        var ready=new CountDownLatch(8); var start=new CountDownLatch(1);
        try {
            List<Future<String>> results=new ArrayList<>();
            for(int i=0;i<8;i++) results.add(pool.submit(()->{
                ready.countDown(); assertTrue(start.await(5,TimeUnit.SECONDS));
                return ledger.credit(OWNER,"req-1","ORD-42",100,false);
            }));
            assertTrue(ready.await(5,TimeUnit.SECONDS)); start.countDown();
            for(var result:results) assertEquals("CREDITED:req-1:100",result.get(10,TimeUnit.SECONDS));
            assertEquals(1,ledger.effects()); assertEquals(100,ledger.balance());
            System.out.println("concurrent requests=8 effects=1 balance=100");
        } finally { start.countDown(); pool.shutdownNow(); }
    }
    @Test void unauthorizedReplayCannotReadSavedResult() {
        var ledger=new CreditLedger(); ledger.credit(OWNER,"req-1","ORD-42",100,false);
        assertEquals("ORDER_UNAVAILABLE",ledger.credit(new OrderTools.Caller("acme","user-8"),"req-1","ORD-42",100,false));
        assertEquals(1,ledger.effects());
    }
    @Test void distinctBusinessRequestsAreNotMerged() {
        var ledger=new CreditLedger(); ledger.credit(OWNER,"req-1","ORD-42",100,false);
        ledger.credit(OWNER,"req-2","ORD-42",100,false);
        assertEquals(2,ledger.effects()); assertEquals(200,ledger.balance());
    }
}

