package com.tecshare;

import java.util.HashMap;
import java.util.Map;

/** Single-process fixture. No network calls, persistence, or crash recovery. */
public final class CreditLedger {
    private record Key(String tenant, String actor, String operation, String requestId) {}
    private record Completed(String orderId, long cents, String result) {}
    private final Map<Key, Completed> completed = new HashMap<>();
    private long balance;
    private int effects;

    public synchronized String credit(OrderTools.Caller caller, String requestId,
                                      String orderId, long cents, boolean failBeforeEffect) {
        // Policy runs before replay lookup, even for an already completed key.
        if (!"acme".equals(caller.tenant()) || !"user-7".equals(caller.actor())
                || !"ORD-42".equals(orderId)) return "ORDER_UNAVAILABLE";
        if (requestId == null || requestId.isBlank() || cents <= 0) return "INVALID_ARGUMENT";
        Key key = new Key(caller.tenant(), caller.actor(), "credit", requestId);
        Completed previous = completed.get(key);
        if (previous != null) {
            if (!previous.orderId().equals(orderId) || previous.cents() != cents)
                return "IDEMPOTENCY_CONFLICT";
            return previous.result();
        }
        // Deliberately before any mutation: safe retry is asserted only for this failure window.
        if (failBeforeEffect) throw new IllegalStateException("injected before business effect");
        long next = Math.addExact(balance, cents);
        String result = "CREDITED:" + requestId + ":" + cents;
        balance = next;
        effects++;
        completed.put(key, new Completed(orderId, cents, result));
        return result;
    }
    public synchronized long balance() { return balance; }
    public synchronized int effects() { return effects; }
}
