package com.tecshare;

import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.ai.tool.annotation.Tool;

public final class OrderTools {
    public record Caller(String tenant, String actor) {}
    private final Caller caller;
    public final AtomicInteger methodEntries = new AtomicInteger();
    public final AtomicInteger businessReads = new AtomicInteger();

    // Construct per authenticated request. Caller is not a model argument.
    public OrderTools(Caller caller) { this.caller = caller; }

    @Tool(description = "Read an order status under the authenticated caller's permissions")
    public String orderStatus(String orderId) {
        methodEntries.incrementAndGet();
        if (orderId == null || orderId.isBlank()) return "INVALID_ARGUMENT";
        // Synthetic owner/tenant lookup. Denied and missing use one public result.
        if (!"acme".equals(caller.tenant()) || !"user-7".equals(caller.actor())
                || !"ORD-42".equals(orderId)) return "ORDER_UNAVAILABLE";
        businessReads.incrementAndGet();
        return "PAID";
    }
}
