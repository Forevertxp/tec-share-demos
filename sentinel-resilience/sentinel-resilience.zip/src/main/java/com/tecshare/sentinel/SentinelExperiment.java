package com.tecshare.sentinel;

import com.alibaba.csp.sentinel.Entry;
import com.alibaba.csp.sentinel.SphU;
import com.alibaba.csp.sentinel.Tracer;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import com.alibaba.csp.sentinel.slots.block.RuleConstant;
import com.alibaba.csp.sentinel.slots.block.degrade.DegradeRule;
import com.alibaba.csp.sentinel.slots.block.degrade.DegradeRuleManager;
import com.alibaba.csp.sentinel.slots.block.degrade.circuitbreaker.EventObserverRegistry;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRule;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRuleManager;
import java.util.*;
import java.util.concurrent.*;

public final class SentinelExperiment {
    public record Result(String outcome, long nanos, boolean downstreamCalled) {
        public String applicationStatus() {
            return switch (outcome) {
                case "SUCCESS" -> "VALUE_AVAILABLE";
                case "BLOCKED" -> "UNAVAILABLE_BEFORE_DISPATCH";
                case "FAILED" -> "DOWNSTREAM_FAILED";
                default -> throw new IllegalStateException("Unexpected outcome");
            };
        }
    }

    public static void configure(String resource, String mode) {
        FlowRuleManager.loadRules(List.of());
        DegradeRuleManager.loadRules(List.of());
        switch (mode) {
            case "off" -> { }
            case "flow" -> FlowRuleManager.loadRules(List.of(new FlowRule(resource)
                    .setGrade(RuleConstant.FLOW_GRADE_QPS).setCount(20)));
            case "circuit" -> DegradeRuleManager.loadRules(List.of(new DegradeRule(resource)
                    .setGrade(RuleConstant.DEGRADE_GRADE_EXCEPTION_RATIO).setCount(0.3)
                    .setMinRequestAmount(10).setStatIntervalMs(1000).setTimeWindow(1)));
            default -> throw new IllegalArgumentException("mode must be off, flow or circuit");
        }
    }

    public static Result request(String resource, boolean fail, int delayMs) throws InterruptedException {
        long start = System.nanoTime();
        Entry entry;
        try {
            entry = SphU.entry(resource);
        } catch (BlockException blocked) {
            return new Result("BLOCKED", System.nanoTime() - start, false);
        }
        String outcome;
        try {
            Thread.sleep(delayMs); // Synthetic downstream latency; not an HTTP timeout.
            if (fail) throw new IllegalStateException("injected downstream failure");
            outcome = "SUCCESS";
        } catch (RuntimeException failure) {
            Tracer.traceEntry(failure, entry); // Before exit so Sentinel sees the business failure.
            outcome = "FAILED";
        } finally {
            entry.exit();
        }
        return new Result(outcome, System.nanoTime() - start, true);
    }

    public static void main(String[] args) throws Exception {
        String mode = args.length == 0 ? "circuit" : args[0];
        int perWorker = args.length > 1 ? Integer.parseInt(args[1]) : 100;
        int workerCount = args.length > 2 ? Integer.parseInt(args[2]) : 8;
        if (perWorker <= 0 || workerCount <= 0) throw new IllegalArgumentException("Positive counts required");
        System.setProperty("csp.sentinel.log.dir", "sentinel-resilience/target/sentinel-logs");
        System.setProperty("EAGLEEYE.LOG.PATH", "sentinel-resilience/target/eagleeye-logs");
        String resource = "experiment-" + mode;
        EventObserverRegistry.getInstance().addStateChangeObserver("trace", (previous, next, rule, snapshot) ->
                System.err.println("breaker resource=" + rule.getResource() + " " + previous + " -> " + next));
        configure(resource, mode);
        // Initialize core outside the timed load; use a different resource to avoid populating test metrics.
        request("warmup-only", false, 0);
        ExecutorService executor = Executors.newFixedThreadPool(workerCount);
        CountDownLatch startGate = new CountDownLatch(1);
        List<Future<List<Result>>> futures = new ArrayList<>();
        long started;
        List<Result> results = new ArrayList<>();
        try {
            for (int worker = 0; worker < workerCount; worker++) {
                final int workerId = worker;
                futures.add(executor.submit(() -> {
                    startGate.await();
                    List<Result> local = new ArrayList<>();
                    for (int i = 0; i < perWorker; i++) {
                        local.add(request(resource, (workerId * perWorker + i) % 3 == 0, 10));
                    }
                    return local;
                }));
            }
            started = System.nanoTime();
            startGate.countDown();
            for (Future<List<Result>> f : futures) results.addAll(f.get(60, TimeUnit.SECONDS));
        } finally {
            executor.shutdownNow();
            executor.awaitTermination(5, TimeUnit.SECONDS);
        }
        double elapsed = (System.nanoTime() - started) / 1e9;
        System.out.printf(Locale.ROOT, "mode=%s requests=%d workers=%d elapsed_seconds=%.6f completed_per_second=%.2f%n",
                mode, results.size(), workerCount, elapsed, results.size() / elapsed);
        System.out.println("outcome,count,p95_ms,downstream_calls");
        for (String outcome : List.of("SUCCESS", "FAILED", "BLOCKED")) {
            List<Result> group = results.stream().filter(r -> r.outcome().equals(outcome)).sorted(Comparator.comparingLong(Result::nanos)).toList();
            double p95 = group.isEmpty() ? Double.NaN : group.get((int) Math.ceil(group.size() * 0.95) - 1).nanos() / 1e6;
            System.out.printf(Locale.ROOT, "%s,%d,%.6f,%d%n", outcome, group.size(), p95, group.stream().filter(Result::downstreamCalled).count());
        }
        for (String outcome : List.of("BLOCKED", "FAILED")) {
            results.stream().filter(result -> result.outcome().equals(outcome)).limit(3).forEach(result ->
                    System.out.println("fallback outcome=" + result.outcome() + " status=" + result.applicationStatus()
                            + " downstream_called=" + result.downstreamCalled() + " business_success=false"));
        }
    }
}
