package com.tecshare.sentinel;

import static org.junit.jupiter.api.Assertions.*;
import com.alibaba.csp.sentinel.Entry;
import com.alibaba.csp.sentinel.SphU;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import com.alibaba.csp.sentinel.slots.block.RuleConstant;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRule;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRuleManager;
import java.util.List;
import java.util.concurrent.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

class SentinelExperimentTest {
    @AfterEach void clearRules() { SentinelExperiment.configure("unused", "off"); }
    @Test void offModeSeparatesFailureFromSuccess() throws Exception {
        SentinelExperiment.configure("off-test", "off");
        assertEquals("SUCCESS", SentinelExperiment.request("off-test", false, 0).outcome());
        var failed = SentinelExperiment.request("off-test", true, 0);
        assertEquals("FAILED", failed.outcome());
        assertEquals("DOWNSTREAM_FAILED", failed.applicationStatus());
        assertTrue(failed.downstreamCalled());
    }
    @Test void occupiedThreadLimitRejectsBeforeCallingDownstream() throws Exception {
        String resource = "thread-limit-test";
        FlowRuleManager.loadRules(List.of(new FlowRule(resource).setGrade(RuleConstant.FLOW_GRADE_THREAD).setCount(1)));
        Entry occupied = SphU.entry(resource);
        ExecutorService executor = Executors.newSingleThreadExecutor();
        try {
            var blocked = executor.submit(() -> SentinelExperiment.request(resource, false, 0)).get(5, TimeUnit.SECONDS);
            assertEquals("BLOCKED", blocked.outcome());
            assertEquals("UNAVAILABLE_BEFORE_DISPATCH", blocked.applicationStatus());
            assertFalse(blocked.downstreamCalled());
        } finally { occupied.exit(); executor.shutdownNow(); }
        assertEquals("SUCCESS", SentinelExperiment.request(resource, false, 0).outcome());
    }
    @Test void tracedErrorsOpenBreakerAndSuccessfulProbeClosesIt() throws Exception {
        String resource = "circuit-test";
        SentinelExperiment.configure(resource, "circuit");
        for (int i = 0; i < 10; i++) assertEquals("FAILED", SentinelExperiment.request(resource, true, 0).outcome());
        var blocked = SentinelExperiment.request(resource, false, 0);
        assertEquals("BLOCKED", blocked.outcome());
        assertFalse(blocked.downstreamCalled());
        long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(5);
        String outcome;
        do {
            Thread.sleep(25);
            outcome = SentinelExperiment.request(resource, false, 0).outcome();
        } while (outcome.equals("BLOCKED") && System.nanoTime() < deadline);
        assertEquals("SUCCESS", outcome, "No half-open probe admitted within five seconds");
        assertEquals("SUCCESS", SentinelExperiment.request(resource, false, 0).outcome());
    }
    @Test void invalidModeIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> SentinelExperiment.configure("invalid", "magic"));
    }
}
